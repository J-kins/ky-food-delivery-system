# NIHE Budget Breakdown — Input File Set

**Project:** National Integrated Healthcare Ecosystem (NIHE)
**Sponsor:** Ministry of Health, Uganda
**Version:** 1.1  |  **Total Budget:** USD 1,250,000  |  **Period:** 2026-07-01 to 2028-09-30

This package contains all **9 Budget Breakdown Generator input files**, located
in `inputs/`, producing an Excel workbook (`.xlsx`) and a Visio dashboard
(`.vsdx`) from a single dataset.

---

## File summary

| # | File | Bundle | Used by |
|---|------|--------|---------|
| 1 | `budget_metadata_input.json` | Shared | All merges |
| 2 | `budget_categories_input.json` | Shared | Excel + Visio |
| 3 | `budget_line_items_input.json` | Shared (Excel data) | Excel only |
| 4 | `budget_monthly_burn_rate_input.json` | Shared | Excel + Visio |
| 5 | `budget_excel_styling_input.json` | Excel | Excel merge |
| 6 | `budget_visio_dashboard_input.json` | Visio | Visio merge |
| **7** | **`budget_excel_input.json`** | **Excel MAIN** | `--excel-only` |
| **8** | **`budget_visio_input.json`** | **Visio MAIN** | `--visio-only` |
| **9** | **`budget_input.json`** | **Combined MAIN** | Full package |

All 25 cross-file consistency rules from the spec have been validated programmatically
before writing any file.

---

## Budget at a glance

| Category | Budget (USD) | % |
|----------|------------:|---|
| Personnel | 450,000 | 36.0% |
| GIS Infrastructure | 150,000 | 12.0% |
| Cloud Hosting & Infrastructure | 130,000 | 10.4% |
| Software Licensing | 110,000 | 8.8% |
| Training & Capacity Building | 100,000 | 8.0% |
| Custom Software Development | 90,000 | 7.2% |
| End-User Hardware & Devices | 80,000 | 6.4% |
| Contingency | 50,000 | 4.0% |
| Networking Equipment | 40,000 | 3.2% |
| Monitoring & Evaluation | 30,000 | 2.4% |
| Communications & Change Management | 20,000 | 1.6% |
| **TOTAL** | **1,250,000** | **100%** |

---

## Key numbers

- **11** categories, **71** line items, **27** burn-rate months
- Every line item satisfies `total = qty × unit_cost` (rule 10)
- Every category budget equals the sum of its line items (rule 11)
- All three grand totals reconcile to exactly **USD 1,250,000** (rule 6)
- `budget_visio_input.json` has `"line_items": []` as required (rule 2)
- `budget_excel_input.json` contains `styling` but no `layout` (rule 3a)
- `budget_visio_input.json` contains `layout` and `dashboard` (rule 3b)
- `categories[]` and `monthly_burn_rate[]` are **byte-for-byte identical**
  across the Excel MAIN, Visio MAIN, and Combined MAIN (rule 4)

---

## Burn rate design

The 27-month burn rate follows the project's phase structure:

| Phase | Months | Monthly Range |
|-------|--------|---------------|
| Kickoff & Team Assembly | Jul–Aug 2026 | $22K–$28K |
| Requirements Finalisation | Sep 2026 | $32K |
| Architecture Design | Oct–Nov 2026 | $43K–$47K |
| Development Sprints 1–5 | Dec 2026–Apr 2027 | $58K–$72K |
| Core EHR Completion | May–Jun 2027 | $63K–$65K |
| Security Certification / Pre-Pilot | Jul 2027 | $57K |
| Pilot Deployment & Stabilisation | Aug–Sep 2027 | $50K–$52K |
| Pilot Evaluation & Rollout Prep | Oct–Nov 2027 | $46K–$48K |
| National Rollout Phases 1 & 2 | Dec 2027–May 2028 | $36K–$44K |
| Full National Deployment | Jun 2028 | $34K |
| Hypercare & Stabilisation | Jul–Aug 2028 | $28K–$32K |
| Handover & Project Close | Sep 2028 | $22K |

All actual spend values are `0` — the project starts 2026-07-01 and this
file set was generated at project inception (2026-06-22).

---

## Run commands

```bash
# Full package (Excel + Visio)
python budget_breakdown_generator/cli.py \
  national-integrated-healthcare-ecosystem/inputs/budget_input.json \
  -o national-integrated-healthcare-ecosystem/output

# Excel only
python budget_breakdown_generator/cli.py \
  national-integrated-healthcare-ecosystem/inputs/budget_excel_input.json \
  --excel-only -o national-integrated-healthcare-ecosystem/output

# Visio only
python budget_breakdown_generator/cli.py \
  national-integrated-healthcare-ecosystem/inputs/budget_visio_input.json \
  --visio-only -o national-integrated-healthcare-ecosystem/output

# Validate only (no output generated)
python budget_breakdown_generator/cli.py \
  national-integrated-healthcare-ecosystem/inputs/budget_input.json \
  --validate-only
```

## Expected outputs

- `output/budget-breakdown.xlsx` — Excel workbook with Budget Summary,
  Detailed Breakdown, Monthly Burn Rate, and DataConnection sheets
- `output/budget-breakdown.vsdx` — Visio dashboard with KPI bar,
  bar chart, pie chart, and burn-rate chart
