# NIHE Stakeholder Diagram — Input File Set

**Project:** National Integrated Healthcare Ecosystem (NIHE)
**Sponsor:** Ministry of Health, Uganda
**Version:** 1.1 (expanded)

This package contains all 6 Stakeholder Diagram Generator input files, located
in `inputs/`, ready to be validated and rendered into the five stakeholder
diagrams.

## What's in here

| # | File | Purpose | Stakeholders | Nodes/Relationships |
|---|------|---------|---------------|----------------------|
| 1 | `stakeholder_register_input.json` | Stakeholder Register (source of truth) | 15 | — |
| 2 | `power_interest_input.json` | Power-Interest Matrix (4 quadrants) | 15 | — |
| 3 | `influence_network_input.json` | Influence Network | 15 nodes | 18 relationships, 4 groups |
| 4 | `salience_model_input.json` | Salience Model (Mitchell, Agle & Wood) | 15 | — |
| 5 | `stakeholder_map_input.json` | Stakeholder Ecosystem Map (concentric rings) | 15 | 15 relationships |
| 6 | **`stakeholder_input.json`** | **MAIN (combined)** | **All 5 sections merged** | **All above** |

Every cross-reference has been validated programmatically:
- All 15 register stakeholder IDs appear in exactly one Power-Interest quadrant
- All 15 influence-network nodes map 1:1 to register stakeholder IDs, every relationship references a valid node, and every node belongs to exactly one group
- All 15 salience-model and stakeholder-map entries match the register 1:1
- No relationship in any file references a non-existent stakeholder/node ID

## What was expanded vs. the original draft

The original draft had 12 stakeholders. Three were added — each with a full
register entry, a Power-Interest quadrant placement, an influence-network
node + relationships, a salience-model entry, and a stakeholder-map node +
relationships — so nothing is "half-wired":

- **S-013 — Civil Society & Patient Advocacy Groups**: represents community
  and patient-rights interests; placed in *Keep Informed* (low power, high
  legitimacy/urgency); linked as advocating for Patients (S-001).
- **S-014 — Pharmaceutical Suppliers & Distributors**: the medicine supply
  chain partner behind the online pharmacy and facility inventory modules;
  placed in *Keep Satisfied*; linked as supplying Healthcare Facilities (S-002).
- **S-015 — Insurance & Social Protection Schemes**: a forward-looking,
  low-urgency stakeholder consistent with the Project Charter's decision to
  keep insurance integration out of the current scope; this is the first
  stakeholder populating the previously-empty **Monitor** quadrant, and is
  linked as a future-integration partner to the Ministry of Health (S-005).

Other detail added:
- Two extra engagement activities per Power-Interest quadrant (e.g. "Direct
  hotline for service interruptions," "Annual stakeholder satisfaction survey")
- Three new influence-network relationships (supply chain, advocacy, future
  insurance readiness) and the External Actors group extended accordingly
- Version bumped to 1.1 and stakeholder counts/statistics updated throughout

## Next steps

1. Files are already placed at `national-integrated-healthcare-ecosystem/inputs/`.

2. **Validate:**
   ```bash
   python stakeholder_diagram_generator/cli.py \
     national-integrated-healthcare-ecosystem/inputs/stakeholder_input.json \
     --validate-only
   ```

3. **Generate:**
   ```bash
   python stakeholder_diagram_generator/cli.py \
     national-integrated-healthcare-ecosystem/inputs/stakeholder_input.json \
     -o national-integrated-healthcare-ecosystem/output
   ```

4. **Generate combined Visio package:**
   ```bash
   python stakeholder_diagram_generator/cli.py \
     national-integrated-healthcare-ecosystem/inputs/stakeholder_input.json \
     -o national-integrated-healthcare-ecosystem/output --combined
   ```

> Note: file 6 (`stakeholder_input.json`) is pre-merged for convenience and
> duplicates files 1–5. If your `cli.py` regenerates the combined file
> automatically from the individual inputs, treat file 6 as a working
> reference/fallback rather than a required input.

## Updated statistics summary

| Metric | Value |
|--------|-------|
| Total Stakeholders | 15 |
| Primary Stakeholders | 6 (S-001, S-002, S-003, S-005, S-006, S-012) |
| Secondary Stakeholders | 9 (S-004, S-007, S-008, S-009, S-010, S-011, S-013, S-014, S-015) |
| Key Players (Manage Closely) | 4 (S-002, S-003, S-005, S-006) |
| Keep Satisfied | 4 (S-004, S-010, S-011, S-014) |
| Keep Informed | 6 (S-001, S-007, S-008, S-009, S-012, S-013) |
| Monitor | 1 (S-015) |
| Definitive Salience | 4 (S-002, S-003, S-005, S-006) |
| Dependent Salience | 2 (S-001, S-013) |
| Influence Network Nodes | 15 |
| Influence Network Relationships | 18 |
| Influence Network Groups | 4 |
| Ecosystem Map Relationships | 15 |
